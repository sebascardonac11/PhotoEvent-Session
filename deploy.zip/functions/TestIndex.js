const index = require('../index');
const jwt_decode = require('jwt-decode');
const Session = require('./session');
//const event = require('./requesExample');
const event = require('./requestExampleGetPhotos');
//const event = require('./requestExamplePOST');

index.handler(event,{},{});